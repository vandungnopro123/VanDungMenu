HUONG DAN THEM VAO REPOSITORY VanDungMenu

1. Giai nen goi nay.
2. Tai GitHub: https://github.com/vandungnopro123/VanDungMenu
3. Chon Add file > Upload files.
4. Tai len cac muc:
   - VDUNGZKeyGate/Makefile
   - VDUNGZKeyGate/Tweak.xm
   - VDUNGZKeyGate/control
   - VDUNGZKeyGate/README_VI.txt
   - .github/workflows/build-keygate.yml
5. Commit changes vao nhanh main.
6. Mo Actions > Build VDUNGZ KeyGate > Run workflow.
7. Khi run xanh, mo run do > Artifacts > VDUNGZKeyGate-dylib-arm64 de tai dylib.

Luu y:
- Day la source de build dylib, chua phai TIPA da duoc chen dylib.
- GitHub connection trong phien nay chi doc duoc repository, khong co quyen ghi file (API tra 403), nen ban can upload thu cong.
- Dylib chi hien man hinh nhap key va goi API; chua hook vao ham START/STOP cua binary app.
- Can tao key moi chua tung test voi device_id khac. Key PKBU7... da duoc gui voi device_id test-device-001, co the da bi gan vao thiet bi thu.
- Khong chia se key quan tri, mat khau hosting hoac token GitHub.
